import { Box } from '@mui/material'
import React from 'react'
import StudentsList from './Students/StudentsList'

export const Components = () => {
  return (
    <Box>
        <StudentsList />
    </Box>
  )
}

